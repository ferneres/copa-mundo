<?php 

require __DIR__ . "/vendor/autoload.php";
require __DIR__ . "/App/Routes/route.php";